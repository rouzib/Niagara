"""Example workflows for Niagara."""
